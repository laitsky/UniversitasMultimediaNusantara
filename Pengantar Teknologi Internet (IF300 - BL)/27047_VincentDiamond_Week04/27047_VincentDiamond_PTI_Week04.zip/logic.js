document.getElementById("p1").innerHTML = "New text!";
document.getElementById("x1").setAttribute("style", "color: red");